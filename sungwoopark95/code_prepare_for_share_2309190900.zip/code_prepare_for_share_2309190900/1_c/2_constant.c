#include <stdio.h>
#define MY_CONST 10
int main(void){
    printf("You've defined a fixed value %d as a MY_CONST\n", MY_CONST);
    return 0;
}