# leetHub

[![LeetCode user sasageyo](https://img.shields.io/badge/dynamic/json?style=for-the-badge&labelColor=black&color=%23ffa116&label=Solved&query=solvedOverTotal&url=https%3A%2F%2Fleetcode-badge.vercel.app%2Fapi%2Fusers%2Fsasageyo&logo=leetcode&logoColor=yellow)](https://leetcode.com/sasageyo/)
[![](https://badges.peiyuan.ch/leetcode/sasageyo/ranking?logo=leetcode&label=sasageyo&style=for-the-badge&color=green)](https://leetcode.com/sasageyo/)
[![](https://cp-logo.vercel.app/leetcode/sasageyo)](https://leetcode.com/sasageyo/)

## Accuracy 

![](https://badges.peiyuan.ch/leetcode/sasageyo/rate?difficulty=all)
![](https://badges.peiyuan.ch/leetcode/sasageyo/rate?difficulty=medium)
![](https://badges.peiyuan.ch/leetcode/sasageyo/rate?difficulty=hard)
![](https://badges.peiyuan.ch/leetcode/sasageyo/rate?difficulty=easy)

## Activity 
![](https://leetcode.card.workers.dev/?username=sasageyo&theme=unicorn&extension=activity)


- Collection of LeetCode questions to ace the coding interview! - Created using [LeetHub](https://github.com/QasimWani/LeetHub)
- To get count put in console 
```js
document.getElementsByClassName('Box-row--focus-gray').length
```
