#include "instructor.h"
#include <stdio.h>

int main(void){
    Instructor::Test();
    return 0;
}