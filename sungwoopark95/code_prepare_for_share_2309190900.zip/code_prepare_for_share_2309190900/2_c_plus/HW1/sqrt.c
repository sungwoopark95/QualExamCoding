#include <stdio.h>
#include <math.h>

int main() {
  double x;
  scanf("%lf", &x);
  printf("%f\n", sqrt(x));
  return 0;
}
