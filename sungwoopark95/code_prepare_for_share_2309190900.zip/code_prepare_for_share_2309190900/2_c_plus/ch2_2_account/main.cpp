#include "account.h"
#include <stdio.h>

int main(void){
    Account::TestOneMonth();
    return 0;
}