#include "bear.h"
#include "mommabear.h"
#include <stdio.h>

int main(void){
    Mommabear::TestBears();

	// Bear* cub;
	// Mommabear* mom;
	// cub = new Bear(50);
	// mom = new Mommabear(300);
	
	
	// printf("%g\n", cub->Meanness());
	// printf("%g\n", mom->Meanness());
	// mom->SetCub(cub);
	// cub->SetWeight(75);
	// printf("%g\n", mom->TotalMeanness());

    return 0;
}