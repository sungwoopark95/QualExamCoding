[Discussion Post (created on 31/0/2021 at 12:6)](https://leetcode.com/problems/repeated-substring-pattern/discuss/1043935/String-Rotation-O(n)-Python)  
<h2>459. Repeated Substring Pattern</h2><h3>Easy</h3><hr><div><p>Given a non-empty string check if it can be constructed by taking a substring of it and appending multiple copies of the substring together. You may assume the given string consists of lowercase English letters only and its length will not exceed 10000.</p>

<p>&nbsp;</p>

<p><b>Example 1:</b></p>

<pre><b>Input:</b> "abab"
<b>Output:</b> True
<b>Explanation:</b> It's the substring "ab" twice.
</pre>

<p><b>Example 2:</b></p>

<pre><b>Input:</b> "aba"
<b>Output:</b> False
</pre>

<p><b>Example 3:</b></p>

<pre><b>Input:</b> "abcabcabcabc"
<b>Output:</b> True
<b>Explanation:</b> It's the substring "abc" four times. (And the substring "abcabc" twice.)
</pre>
</div>