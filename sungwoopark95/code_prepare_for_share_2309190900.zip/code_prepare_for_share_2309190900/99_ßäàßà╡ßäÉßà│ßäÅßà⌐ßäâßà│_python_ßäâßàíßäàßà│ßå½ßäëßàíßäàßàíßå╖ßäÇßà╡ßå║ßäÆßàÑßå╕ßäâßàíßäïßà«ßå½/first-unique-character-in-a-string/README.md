<h2>387. First Unique Character in a String</h2><h3>Easy</h3><hr><div><p>Given a string, find the first non-repeating character in it and return its index. If it doesn't exist, return -1.</p>

<p><b>Examples:</b></p>

<pre>s = "leetcode"
return 0.

s = "loveleetcode"
return 2.
</pre>

<p>&nbsp;</p>

<p><b>Note:</b> You may assume the string contains only lowercase English letters.</p>
</div>