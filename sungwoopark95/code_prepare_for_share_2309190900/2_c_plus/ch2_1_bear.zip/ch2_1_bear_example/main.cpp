#include "bear.h"
#include "mommabear.h"

int main(void)
{
Mommabear::TestBears();
return 0;
}