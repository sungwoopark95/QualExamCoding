#include <stdio.h>
#include "mommabear.h"

Mommabear::Mommabear(float aWeight):Bear(aWeight)
{
	cub=NULL;
	}							

Bear* Mommabear::GetCub(void){
	return cub;
}

void Mommabear::SetCub(Bear *aCub){
	cub = aCub;
}

float Mommabear::Meanness(void){
	return (Bear::Meanness()*2);
}

float Mommabear::TotalMeanness(void) {
	if (cub==NULL)
		return (Meanness());
	else
		return (Meanness()+cub->Meanness());
}

void Mommabear::TestBears(void){
	Bear* cub;
	Mommabear* mom;
	cub = new Bear(50);
	mom = new Mommabear(300);
	
	
	printf("%g\n", cub->Meanness());
	printf("%g\n", mom->Meanness());
	mom->SetCub(cub);
	cub->SetWeight(75);
	printf("%g\n", mom->TotalMeanness());
}